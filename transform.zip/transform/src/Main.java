import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.SQLOutput;
import java.util.Scanner;

public class Main {
    public static void main(String argy[]) throws UnknownHostException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("do you want DNS?(y/n)");
        String answer = scanner.nextLine();
        if (answer.startsWith("y")) {
            InetAddress localHost = InetAddress.getLocalHost();
            System.out.println(localHost.getHostAddress());
            String DNS = localHost.getHostAddress();
            Scanner scanner1 = new Scanner(System.in);
            System.out.println("do you want to turn it to DNS?(y/n)");
            String answer1 = scanner1.nextLine();
            if (answer1.startsWith("y")){
                Scanner scanner2 = new Scanner(System.in);
                System.out.println("what do you want to call it?");
                String answer3 = scanner2.nextLine();
                Scanner scanner4 = new Scanner(System.in);
                System.out.println(answer3+" is you're IP address");
                System.out.println("testing (call your DNS)");
                String answer4 = scanner4.nextLine();
                if (answer4.equals(answer3)) {
                    System.out.println(localHost.getHostAddress());
                } else if (answer4.equals(localHost.getHostAddress())){
                    System.out.println("you're IP address is "+answer3);
                }
                else {
                    System.out.println("this app is only for turning IP addresses to DNS names");
                }
            }else {
                System.out.println("this app is only for turn IP to DNS");
            }
        }else {
            System.out.println("this app is only for turn IP to DNS");
        }

    }
}
